<?php
    setcookie("username", '', time() - 3600, "/");
    setcookie("token", '', time() - 3600, "/");
?>
<?php
$width = 25;
if (isset($_COOKIE['token'])) {
$token = $_COOKIE['token'];
$connection = mysqli_connect("localhost","wigglyuser","wigglypass","wiggly");
$game = mysqli_query($connection, "SELECT * FROM games WHERE token='".$token."'");
if (mysqli_num_rows($game) == 0) {
    setcookie('token', '', time()-3600);
    setcookie("pnum", '', time() - 3600);
} else {
    $code = mysqli_fetch_assoc($game);
        $players = explode(",", $code["players"]);
        $playernum = array_search($_COOKIE['username'], $players) + 1;
        setcookie("pnum", '', time() - 3600);
        setcookie("pnum", $playernum, time() + 3600000, "/");
    echo $code["code"];
}
mysqli_close($connection);
} else {
    if (isset($_COOKIE['username'])) {
        $username = $_COOKIE['username'];
    $connection = mysqli_connect("localhost","wigglyuser","wigglypass","wiggly");
    $waitlist = mysqli_query($connection, "SELECT * FROM waitlist WHERE 1");
    if (mysqli_num_rows($waitlist) == 0) {
        $token = bin2hex(openssl_random_pseudo_bytes(16));
        if (mysqli_num_rows(mysqli_query($connection, "SELECT * FROM games WHERE token='" . $token . "'")) == 0) {
            mysqli_query($connection, "INSERT INTO waitlist (token, player1) VALUES ('" . $token . "', '" . $username . "')");
        }
        unset($token);
    } else if (mysqli_num_rows($waitlist) == 1) {
        $waitEntry = mysqli_fetch_assoc($waitlist);
        if ($waitEntry["player1"] == $username || $waitEntry["player2"] == $username || $waitEntry["player3"] == $username) {
            setcookie("token", $waitEntry['token'], time() + 36000000000, '/');
        } else {
        if ($waitEntry["player2"] == "") {
            mysqli_query($connection, "UPDATE waitlist SET player2='" . $username . "'");
            setcookie("token", $waitEntry['token'], time() + 36000000000, '/');
        } else if ($waitEntry["player3"] == "") {
            mysqli_query($connection, "UPDATE waitlist SET player3='" . $username . "'");
            setcookie("token", $waitEntry['token'], time() + 36000000000, '/');
        } else if ($waitEntry["player4"] == "") {
            $players = $waitEntry["player1"] . "," . $waitEntry["player2"] . "," . $waitEntry["player3"] . "," . $_COOKIE['username'];
            $code = rand(0,$width-1) . "," . rand(0, $width-1) . ";" . rand(0,$width-1) . "," . rand(0, $width-1) . ";" . rand(0,$width-1) . "," . rand(0, $width-1) . ";" . rand(0,$width-1) . "," . rand(0, $width-1) . ";" . rand(0,$width-1) . "," . rand(0, $width-1) . ";5|2|5|15;5|2|10|15;5|2|15|15;5|2|20|15";
            mysqli_query($connection, "DELETE FROM waitlist WHERE 1");
            mysqli_query($connection, "INSERT INTO games VALUES ('" . $waitEntry['token'] . "', '" . $players . "', '" . $code . "', 0, 0, 0, 0)");
            setcookie("token", $waitEntry['token'], time() + 36000000000, '/');
        }
    }
    }
    mysqli_close($connection);
    }
}
?>
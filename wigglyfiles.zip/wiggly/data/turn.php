<?php
$token = $_COOKIE['token'];
$playerNum = $_COOKIE['pnum'];
$direction = $_GET['dir'];
$connection = mysqli_connect("localhost","wigglyuser","wigglypass","wiggly");
mysqli_query($connection, "UPDATE games SET dir" . $playerNum . "=" . $direction . " WHERE token='".$token."'");
mysqli_close($connection);
?>
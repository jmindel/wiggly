<?php
    if (isset($_POST['uname']) && isset($_POST['pass'])) {
        $username = $_POST['uname'];
        $password = $_POST['pass'];
    }
    $connection = mysqli_connect("localhost","wigglyuser","wigglypass","wiggly");
    $query = mysqli_query($connection, "SELECT * FROM users WHERE username='" . $username . "' AND password='" . $password . "'");
    if (mysqli_num_rows($query) == 1) {
        setcookie("username", $username, time() + 360000, '/');
        setcookie("password", $password, time() + 360000, '/');
        header('Location: ../wiggly');
    } else {
        header('Location: login.php');
    }
    mysqli_close($connection);
    unset($query);
    unset($username);
    unset($password);
?>
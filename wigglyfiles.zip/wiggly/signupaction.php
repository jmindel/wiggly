<?php
    if (isset($_POST['uname']) && isset($_POST['pass'])) {
        $name = $_POST['name'];
        $username = str_replace([',', '\\', '/', ' ', ';', '|'], '', htmlspecialchars($_POST['uname']));
        $password = htmlspecialchars($_POST['pass']);
    }
    $connection = mysqli_connect("localhost","wigglyuser","wigglypass","wiggly");
    $query = mysqli_query($connection, "SELECT * FROM users WHERE username='" . $username . "'");
    if (mysqli_num_rows($query) > 0) {
        header('Location: signup.php');
    } else {
        $query = mysqli_query($connection, "INSERT INTO users VALUES ('" . $name . "','" . $username . "','" . $password . "')");
        setcookie("username", $username, time() + 360000, '/');
        setcookie("password", $password, time() + 360000, '/');
        header('Location: ../wiggly');
    }
    mysqli_close($connection);
    unset($query);
    unset($username);
    unset($password);
?>
<?php
if (isset($_COOKIE['username'])) {
    header('Location: ../wiggly');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wiggly</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <form action="loginaction.php" method="post">
    <h1>Login</h1>
    <fieldset>
        <h2>Username</h2>
        <input type="text" name="uname" required>
        <h2>Your Password</h2>
        <input type="password" name="pass" required>
    </fieldset>
    <a href="signup.php">Sign Up</a>
    <br>
    <input type="submit" value="Login" id="submitButton">
    </form>
    <script src="dataMain/script.js"></script>
</body>
</html>
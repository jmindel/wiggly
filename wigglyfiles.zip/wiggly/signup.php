<?php
if (isset($_COOKIE['username'])) {
    header('Location: ../wiggly');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wiggly</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <form action="signupaction.php" method="post">
    <h1>Create Your Account</h1>
    <fieldset>
        <h2>Your Name</h2>
        <input type="text" name="name" required>
        <h2>Your Username</h2>
        <input type="text" name="uname" required>
        <h2>Your Password</h2>
        <input type="password" name="pass" required>
    </fieldset>
    <a href="login.php">Log In</a>
    <br>
    <input type="submit" value="Create Account" id="submitButton">
    </form>
</body>
</html>
function getCode() {
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function() {
        var preCode = this.responseText;
        code = preCode;
    }
    xhttp.open("GET", "data/getCode.php");
    xhttp.send();
}

var direction = 1;
var gameWidth = 25;
function turn() {
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", "data/turn.php?dir="+direction);
    xhttp.send();
}



var keys = [87,68,83,65,38,39,40,37];
function addKey(e) {
    var c = e.keyCode;
    var cDir = keys.indexOf(c)%4;
    if (cDir != -1) {
        direction = cDir;
        turn();
    }
}

document.addEventListener("keydown", addKey);


getCode();
setInterval(getCode, 25);

var players = ["player1","player2","player3","player4"];
var code = "";
//0: up
//1: right
//2: down
//3: left
function extractCode(code) {
    if (code == "") {
        return "";
    }
    var extCode = code.split(";");
    for (var i = 0; i < extCode.length; i++) {
        extCode[i] = extCode[i].split(",");
        if (i < 5) {
        for (var j = 0; j < extCode[i].length; j++) {
            extCode[i][j] = parseInt(extCode[i][j]);
        }
    }
    }
    return extCode;
}
var tbl = document.getElementById("gameTable");
tbl.innerHTML = "";
var tr = "<tr></tr>";
var td = "<td></td>";
for (var i = 0; i < gameWidth; i++) {
    tbl.innerHTML += tr;
    var row = tbl.children[tbl.children.length-1];
    for (var j = 0; j < gameWidth; j++) {
        row.innerHTML += td;
    }
}
function draw() {
    var codeArray = extractCode(code);
    if (codeArray == "") {
        return;
    }
    var fruits = document.getElementsByClassName("fruit");
    var pSquares = document.getElementsByClassName("player");
    while (fruits.length > 0) {
        fruits[fruits.length-1].className = "";
    }
    while (pSquares.length > 0) {
        pSquares[pSquares.length-1].className = "";
    }
    for (i = 0; i < 5; i++) {
        tbl.children[codeArray[i][0]].children[codeArray[i][1]].className = "fruit";
    }
    codeArray.splice(0,5);
    for (i = 0; i < codeArray.length; i++) {
        for (j = 0; j < codeArray[i].length; j++) {
            codeArray[i][j] = codeArray[i][j].split("|");
            for (k = 0; k < codeArray[i][j].length; k++) {
                codeArray[i][j][k] = parseInt(codeArray[i][j][k]);
            }
        }
    }

    for (i = 0; i < codeArray.length; i++) {
        var pCode = codeArray[i];
        var posX = pCode[0][2];
        var posY = pCode[0][3];
        first = true;
        for (var i2 = 0; i2 < pCode.length; i2++) {
            var length = pCode[i2][0];
            var dir = pCode[i2][1];
        switch (dir) {
            case 0:
                if (!first) {
                    posY--;
                }
                for (j = 0; j < length; j++) {
                    if (posY >= 0 && posY < gameWidth && posX >= 0 && posX < gameWidth) {
                        tbl.children[posY].children[posX].className = "player player" + (i + 1);
                    }
                    posY--;
                }
                posY++;
                break;
            case 1:
                if (!first) {
                    posX++;
                }
                for (j = 0; j < length; j++) {
                    if (posY >= 0 && posY < gameWidth && posX >= 0 && posX < gameWidth) {
                        tbl.children[posY].children[posX].className = "player player" + (i + 1);
                    }
                    posX++;
                }
                posX--;
                break;
            case 2:
                if (!first) {
                    posY++;
                }
                for (j = 0; j < length; j++) {
                    if (posY >= 0 && posY < gameWidth && posX >= 0 && posX < gameWidth) {
                        tbl.children[posY].children[posX].className = "player player" + (i + 1);
                    }
                    posY++;
                }
                posY--;
                break;
            case 3:
                if (!first) {
                    posX--;
                }
                for (j = 0; j < length; j++) {
                    if (posY >= 0 && posY < gameWidth && posX >= 0 && posX < gameWidth) {
                        tbl.children[posY].children[posX].className = "player player" + (i + 1);
                    }
                    posX--;
                }
                posX++;
                break;
            
        }
        first = false;

    }

}
    counter++;
}
var first = true;
var counter = 0;
function display() {
    alert(counter);
}
setInterval(draw, 25);

function logout() {
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", "data/logout.php");
    xhttp.send();
    document.location = "login.php";
}

document.getElementById("logout").addEventListener("click", logout);
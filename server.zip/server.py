print("Initializing primary MySQL connection...")
import mysql.connector
from time import sleep
from time import time
import random
from threading import *
import os
gameWidth = 24
connection = mysql.connector.connect(host='localhost',database='wiggly',user='wigglyuser',password='wigglypass')
print("Initializing secondary MySQL connection...")
connection2 = mysql.connector.connect(host='localhost',database='wiggly',user='wigglyuser',password='wigglypass')
print("Initializing server console connection...")
connection3 = mysql.connector.connect(host='localhost',database='wiggly',user='wigglyuser',password='wigglypass')
#db_Info = connection.get_server_info()
#print("Database: " + db_Info)
print("Initializing MySQL cursors...")
cursor = connection.cursor()
cursor2 = connection2.cursor()
cursor3 = connection3.cursor()
def mysql(query):
    cursor.execute(query)
    response = cursor.fetchall()
    connection.commit()
    return response

def mysql2(query):
    cursor2.execute(query)
    response = cursor2.fetchall()
    connection2.commit()
    return response

def mysql3(query):
    cursor3.execute(query)
    response = cursor3.fetchall()
    connection3.commit()
    return response
def splitCode(code):
    code = code.split(";")
    for i in range(len(code)):
        code[i] = code[i].split(",")
        for j in range(len(code[i])):
            code[i][j] = code[i][j].split("|")
    return code
counter = 0
def moveForward(code, dirs):
    global gameWidth
    global counter
    fruit = [code[0],code[1],code[2],code[3],code[4]]
    playerCode = code[5:len(code)]
    players = []
    for i in range (len(playerCode)):
        players.append([])
        if (len(playerCode[i][0]) == 1):
            continue
        xPos = int(playerCode[i][0][2])
        yPos = int(playerCode[i][0][3])
        first = True
        for j in range (len(playerCode[i])):
            length = int(playerCode[i][j][0])
            dir = int(playerCode[i][j][1])
            for k in range (length):
                if (first == False):
                    if (dir == 0):
                        yPos -= 1
                    elif (dir == 1):
                        xPos += 1
                    elif (dir == 2):
                        yPos += 1
                    elif (dir == 3):
                        xPos -= 1
                players[i].append([xPos, yPos])
                if (first == True):
                    first = False
        xPos = int(playerCode[i][0][2])
        yPos = int(playerCode[i][0][3])
        if (dirs[0][i] == 0):
            yPos -= 1
        elif (dirs[0][i] == 1):
            xPos += 1
        elif (dirs[0][i] == 2):
            yPos += 1
        elif (dirs[0][i] == 3):
            xPos -= 1
        c = 0
        players[i].insert(0, [xPos, yPos])
        for j in range (len(fruit)):
            if (int(fruit[j][1][0]) == xPos and int(fruit[j][0][0]) == yPos):
                c = 1
                fruit[j] = [[str(random.randrange(0,gameWidth))],[str(random.randrange(0,gameWidth))]]
        if (c == 0):
            players[i].pop(len(players[i])-1)
    return [players, fruit]

def testCollision(players):
    deadPlayers = []
    for i in range (len(players)):
        if (players[i] == []):
            deadPlayers.append(1)
            continue
        deadPlayers.append(0)
        if (players[i][0][0] > gameWidth or players[i][0][0] < 0 or players[i][0][1] > gameWidth or players[i][0][1] < 0):
            deadPlayers[i] = 1
        for j in range (len(players)):
            for k in range (len(players[j])):
                if (k != 0 or j != i):
                    if (players[i][0][0] == players[j][k][0] and players[i][0][1] == players[j][k][1]):
                        deadPlayers[i] = 1
    return deadPlayers

def compress(fruit, players, deadPlayers):
    finalCode = ""
    for i in range (len(fruit)):
        finalCode += str(fruit[i][0][0]) + ","
        finalCode += str(fruit[i][1][0]) + ";"
    for i in range (len(players)):
        if (deadPlayers[i] == 1):
            if (i != 0):
                finalCode += ";0"
            else:
                finalCode += "0"
            continue
        playerCode = ""
        length = 1
        dir = deltaDir(players[i][0], players[i][1])
        xPos = players[i][0][0]
        yPos = players[i][0][1]
        doneFirst = False
        for j in range (len(players[i])-1):
            newDir = deltaDir(players[i][j], players[i][j+1])
            
            if (newDir == dir):
                length += 1
            elif (not doneFirst):
                playerCode += str(length) + "|" + str(dir) + "|" + str(xPos) + "|" + str(yPos)
                doneFirst = True
                length = 1
                dir = newDir
            else:
                playerCode += "," + str(length) + "|" + str(dir)
                length = 1
                dir = newDir
        if (not doneFirst):
            playerCode += str(length) + "|" + str(dir) + "|" + str(xPos) + "|" + str(yPos)
        else:
            playerCode += "," + str(length) + "|" + str(dir)
        if (i != 0):
            finalCode += ";" + playerCode
        else:
            finalCode += playerCode
    return finalCode
def deltaDir(c1, c2):
    if (c2[0] < c1[0]): 
        return 3
    elif (c2[0] > c1[0]):
        return 1
    elif (c2[1] < c1[1]):
        return 0
    elif (c2[1] > c1[1]):
        return 2
    return 0
counter = 0
deadGames = []
stop = True
def reset():
    print("Game resets running!")
    global deadGames
    global stop
    global speed
    while stop:
        sTime = time()
        saveDeadGames = deadGames
        for index in range (len(saveDeadGames)):
            if (saveDeadGames[index] == 1):
                fruits = str(random.randrange(0,gameWidth)) + "," + str(random.randrange(0,gameWidth)) + ";" + str(random.randrange(0,gameWidth)) + "," + str(random.randrange(0,gameWidth)) + ";" + str(random.randrange(0,gameWidth)) + "," + str(random.randrange(0,gameWidth)) + ";" + str(random.randrange(0,gameWidth)) + "," + str(random.randrange(0,gameWidth)) + ";" + str(random.randrange(0,gameWidth)) + "," + str(random.randrange(0,gameWidth))
                mysql2("UPDATE games SET code='" + fruits + ";3|2|5|20;3|2|10|20;3|2|15|20;3|2|20|20', dir1=0, dir2=0, dir3=0, dir4=0 WHERE " + str(index+1))
        while (time() < sTime + speed*3/4):
            sleep(0.001)
counter = 1
speed = 0.04
def gameLoop1():
    print("Game updates running!")
    global deadGames
    global counter
    global stop
    global speed
    while stop:
        sTime = time()
        codes = mysql("SELECT code FROM games")
        dirs = mysql("SELECT dir1, dir2, dir3, dir4 FROM games")
        deadPlayers = []
        deadGames = []
        for i in range (len(codes)):
            newCode = splitCode(codes[i][0])
            output = moveForward(newCode, dirs)
            players = output[0]
            fruit = output[1]
            deadPlayers = testCollision(players)
            if (deadPlayers == [1,1,1,1]):
                deadGames.append(1)
            else:
                deadGames.append(0)
            finalCode = compress(fruit, players, deadPlayers)
            mysql("UPDATE games SET code='" + finalCode + "' WHERE " + str(i+1))
        while (time() < sTime + speed):
            sleep(0.001)
def console():
    global stop
    global speed
    while stop:
        command = input("> ")
        if (command == "stop"):
            print("Stopping...")
            stop = False
            sleep(0.5)
            cursor.close()
            connection.close()
            cursor2.close()
            connection2.close()
            cursor3.close()
            connection3.close()
        elif (command[0:5] == "mysql"):
            if (len(command) > 5):
                try:
                    print(mysql3(command[6:len(command)]))
                except:
                    print("Please enter a valid MySQL query")
            else:
                print("Please enter query")
        elif (command[0:4] == "help"):
            if (len(command) == 4):
                print("Commands:\nstop\nmysql\nhelp\nclear\ncls\nstopnow\nreset\ndbinfo\ndel\nspeed\ndelbyuser\nresetbyuser\nFor specific help on a command, type help [command]")
            elif (command[5:len(command)] == "stop"):
                print("Stops server and closes connections\nSyntax: stop")
            elif (command[5:len(command)] == "mysql"):
                print("Executes a MySQL query on the connected database and returns the response\nSyntax: mysql [query]")
            elif (command[5:len(command)] == "help"):
                print("Get help in general or on a command\nSyntax: help [command]")
            elif (command[5:len(command)] == "clear"):
                print("Clears the console\nSyntax: clear")
            elif (command[5:len(command)] == "cls"):
                print("Clears the console\nSyntax: cls")
            elif (command[5:len(command)] == "stopnow"):
                print("Stops the server immediately, without closing connections\nSyntax: stopnow")
            elif (command[5:len(command)] == "reset"):
                print("Resets a game from its index\nSyntax: reset [game-index]\nNote: index starts at 1")
            elif (command[5:len(command)] == "dbinfo"):
                print("Returns database info\nSyntax: dbinfo")
            elif (command[5:len(command)] == "del"):
                print("Deletes a game from its index\nSyntax: del [game-index]\nNote: index starts at 1")
            elif (command[5:len(command)] == "speed"):
                print("Changes the movement speed of all games, default is 0.04\nSyntax: speed [seconds]\nNote: clientside server updates are fixed-speed")
            elif (command[5:len(command)] == "delbyuser"):
                print("Deletes all games with a given user\nSyntax: delbyuser [user]")
            elif (command[5:len(command)] == "resetbyuser"):
                print("Resets all games with a given user\nSyntax: resetbyuser [user]")
            else:
                print("Unrecognized command")
        elif (command == "clear" or command == "cls"):
            try:
                os.system('cls' if os.name == 'nt' else 'clear')
            except:
                print("Your operating system does not use a recognized clear command")
        elif (command == "stopnow"):
            stop = False
        elif (command[0:6] == "reset "):
            try:
                index = int(command[6:len(command)])
                fruits = str(random.randrange(0,gameWidth)) + "," + str(random.randrange(0,gameWidth)) + ";" + str(random.randrange(0,gameWidth)) + "," + str(random.randrange(0,gameWidth)) + ";" + str(random.randrange(0,gameWidth)) + "," + str(random.randrange(0,gameWidth)) + ";" + str(random.randrange(0,gameWidth)) + "," + str(random.randrange(0,gameWidth)) + ";" + str(random.randrange(0,gameWidth)) + "," + str(random.randrange(0,gameWidth))
                mysql3("UPDATE games SET code='" + fruits + ";3|2|5|20;3|2|10|20;3|2|15|20;3|2|20|20', dir1=0, dir2=0, dir3=0, dir4=0 WHERE " + str(index))
            except:
                print("Please enter a valid numerical index")
        elif (command == "dbinfo"):
            print(connection3.get_server_info())
        elif (command[0:4] == "del "):
            try:
                index = int(command[4:len(command)])
                mysql3("DELETE FROM games WHERE " + str(index))
            except:
                print("Please enter a valid numerical index")
        elif (command[0:5] == "speed"):
            if (len(command) == 5):
                print("Speed is " + str(speed))
            else:
                try:
                    speed = float(command[6:len(command)])
                    print("Speed is now " + str(speed))
                except:
                    print("Please enter a valid speed")
        elif (command[0:9] == "delbyuser"):
            try:
                mysql3("DELETE FROM games WHERE players LIKE '%," + command[10:len(command)] + ",%'")
                mysql3("DELETE FROM games WHERE players LIKE '%," + command[10:len(command)] + "'")
                mysql3("DELETE FROM games WHERE players LIKE '" + command[10:len(command)] + ",%'")
            except:
                print("Please enter a valid username")
        elif (command[0:11] == "resetbyuser"):
            try:
                fruits = str(random.randrange(0,gameWidth)) + "," + str(random.randrange(0,gameWidth)) + ";" + str(random.randrange(0,gameWidth)) + "," + str(random.randrange(0,gameWidth)) + ";" + str(random.randrange(0,gameWidth)) + "," + str(random.randrange(0,gameWidth)) + ";" + str(random.randrange(0,gameWidth)) + "," + str(random.randrange(0,gameWidth)) + ";" + str(random.randrange(0,gameWidth)) + "," + str(random.randrange(0,gameWidth))
                mysql3("UPDATE games SET code='" + fruits + ";3|2|5|20;3|2|10|20;3|2|15|20;3|2|20|20', dir1=0, dir2=0, dir3=0, dir4=0 WHERE players LIKE '%," + command[12:len(command)] + ",%'")
                mysql3("UPDATE games SET code='" + fruits + ";3|2|5|20;3|2|10|20;3|2|15|20;3|2|20|20', dir1=0, dir2=0, dir3=0, dir4=0 WHERE players LIKE '%," + command[12:len(command)] + "'")
                mysql3("UPDATE games SET code='" + fruits + ";3|2|5|20;3|2|10|20;3|2|15|20;3|2|20|20', dir1=0, dir2=0, dir3=0, dir4=0 WHERE players LIKE '" + command[12:len(command)] + ",%'")
            except:
                print("Please enter a valid username")
        else:
            print("Unrecognized command")
print("Starting threads...")
thread1=Thread(target=gameLoop1)
thread2=Thread(target=reset)
thread1.start()
thread2.start()
console()